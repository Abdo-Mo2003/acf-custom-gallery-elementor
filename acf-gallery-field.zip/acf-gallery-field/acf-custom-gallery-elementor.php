<?php
/**
 * Plugin Name: ACF Custom Gallery for Elementor
 * Description: Adds a "Gallery (Free)" ACF field type with drag-to-reorder, compatible with Elementor Basic Gallery (free) and Gallery (Pro) via a Dynamic Tag.
 * Version: 1.1.0
 * Author: Abdo Mo
 * Author URI: https://github.com/Abdo-Mo2003
 * Text Domain: acf-gallery-elementor
 * Requires at least: 5.9
 * Requires PHP: 7.4
 * GitHub Plugin URI: https://github.com/Abdo-Mo2003/acf-custom-gallery-elementor
 * Primary Branch: main
 */

defined( 'ABSPATH' ) || exit;

define( 'ACFGE_PATH',    plugin_dir_path( __FILE__ ) );
define( 'ACFGE_URL',     plugin_dir_url( __FILE__ ) );
define( 'ACFGE_VERSION', '4.1.0' );

/* ---------------------------------------------------------------
 * 1. AUTO-UPDATES VIA GITHUB (Plugin Update Checker)
 *
 *    HOW TO SET UP:
 *    a) Download Plugin Update Checker from:
 *       https://github.com/YahnisElsts/plugin-update-checker/releases/latest
 *    b) Extract and place the library contents into:
 *       includes/plugin-update-checker/
 *    c) Replace YOUR-USERNAME below with your GitHub username
 *    d) Push your plugin to GitHub as:
 *       https://github.com/YOUR-USERNAME/acf-custom-gallery-elementor
 *
 *    TO RELEASE AN UPDATE:
 *    1. Bump the version number in this file header AND in ACFGE_VERSION
 *    2. Commit and push to GitHub
 *    3. Create a new Release/Tag on GitHub (e.g. v4.2.0)
 *    4. WordPress will notify all users of the available update
 * ------------------------------------------------------------- */
add_action( 'init', 'acfge_setup_updater', 5 );
function acfge_setup_updater() {
    $puc_path = ACFGE_PATH . 'includes/plugin-update-checker/plugin-update-checker.php';

    if ( ! file_exists( $puc_path ) ) {
        // Library not installed yet — show an admin notice
        add_action( 'admin_notices', function() {
            if ( ! current_user_can( 'manage_options' ) ) return;
            echo '<div class="notice notice-warning is-dismissible">
                <p><strong>ACF Custom Gallery for Elementor:</strong> 
                Auto-update library not found. 
                <a href="https://github.com/YahnisElsts/plugin-update-checker/releases/latest" target="_blank">
                Download Plugin Update Checker</a> and place it in 
                <code>includes/plugin-update-checker/</code> to enable GitHub updates.</p>
            </div>';
        } );
        return;
    }

    require_once $puc_path;

    // PUC 5.x API
    if ( class_exists( '\YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
        \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://github.com/Abdo-Mo2003/acf-custom-gallery-elementor',
            __FILE__,
            'acf-custom-gallery-elementor'
        );
    }
    // PUC 4.x API (fallback for older versions)
    elseif ( function_exists( 'Puc_v4_Factory::buildUpdateChecker' ) ) {
        Puc_v4_Factory::buildUpdateChecker(
            'https://github.com/Abdo-Mo2003/acf-custom-gallery-elementor',
            __FILE__,
            'acf-custom-gallery-elementor'
        );
    }
}


/* ---------------------------------------------------------------
 * 2. REGISTER CUSTOM ACF FIELD TYPE
 * ------------------------------------------------------------- */
add_action( 'acf/include_field_types', 'acfge_register_field_type' );
add_action( 'acf/register_fields',     'acfge_register_field_type' );
add_action( 'init',                    'acfge_register_field_type', 20 );

function acfge_register_field_type() {
    static $done = false;
    if ( $done ) return;
    if ( ! function_exists( 'acf_register_field_type' ) && ! function_exists( 'acf' ) ) return;

    require_once ACFGE_PATH . 'includes/acf-field-gallery.php';

    if ( function_exists( 'acf_register_field_type' ) ) {
        acf_register_field_type( 'ACFGE_Field_Gallery' );
    } elseif ( function_exists( 'acf' ) ) {
        new ACFGE_Field_Gallery();
    }

    $done = true;
}


/* ---------------------------------------------------------------
 * 3. REGISTER ELEMENTOR DYNAMIC TAG
 *    Plugs into Basic Gallery (free) + Gallery (Pro) widgets.
 * ------------------------------------------------------------- */
add_action( 'elementor/dynamic_tags/register', 'acfge_register_dynamic_tags' );
function acfge_register_dynamic_tags( $dynamic_tags_manager ) {
    require_once ACFGE_PATH . 'includes/dynamic-tag-gallery.php';

    $dynamic_tags_manager->register_group( 'acfge', [
        'title' => 'ACF Gallery',
    ] );

    $dynamic_tags_manager->register( new ACFGE_Dynamic_Tag_Gallery() );
}